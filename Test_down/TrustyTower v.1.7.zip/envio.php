<?PHP

$to = "richardd82@gmail.com";
$subject = "Asunto del email";
$message = "Este es mi primer envío de email con PHP";
$headers = "From: mi@cuentadeemail.com";

mail($to, $subject, $message, $headers);
?>
