$(document).ready(function(){

  $("#inicio").click(function() {
    $("html, body").animate({
      scrollTop: $("#home").offset().top
    }, 1000);
  });
  $("#quienes").click(function() {
    $("html, body").animate({
      scrollTop: $("#about").offset().top
    }, 1000);
  });
  $("#productos").click(function() {
    $("html, body").animate({
      scrollTop: $("#portfolio").offset().top
    }, 1000);
  });
  $("#contacto").click(function() {
    $("html, body").animate({
      scrollTop: $("#contact  ").offset().top
    }, 1000);
  });
  $("#footerBtn").click(function() {
    $("html, body").animate({
      scrollTop: $("#home  ").offset().top
    }, 1000);
  });
  $('#validate').click(function() {

    var regex = /[\w-\.]{2,}@([\w-]{2,}\.)*([\w-]{2,}\.)[\w-]{2,4}/;

    if (regex.test($('#Email').val().trim())) {
      $('#validate').click(function(){
        $('#result').css('display', 'none');
        $('#load').css('display', 'inline-block');

      var url = "envio.php";
      $.ajax({
         type: "POST",
         url: url,
         data: $("#fc").serialize(),
         success: function(data)
         {
           $('#result').css('display', 'inline-block');
           $('#load').css('display', 'none');
           $('#result').html(data);
         }
       });
     });
    } else {
        alert('La direccón de correo no es válida');
    }
  });
});
