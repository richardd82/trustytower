<?PHP

$nombre = $_POST['nombre'];
$deQuien = $_POST['email'];
$mensaje = $_POST['mensaje'];



$to = "richardd82@gmail.com";
$subject = "Asunto del email";
$message = $mensaje;
$headers = "From: ". $deQuien;

mail($to, $subject, $message, $headers);
?>
