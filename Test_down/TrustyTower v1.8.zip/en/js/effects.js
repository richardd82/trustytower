$(document).ready(function(){

  $("#inicio").click(function() {
    $("html, body").animate({
      scrollTop: $("#home").offset().top
    }, 1000);
  });
  $("#quienes").click(function() {
    $("html, body").animate({
      scrollTop: $("#about").offset().top
    }, 1000);
  });
  $("#productos").click(function() {
    $("html, body").animate({
      scrollTop: $("#portfolio").offset().top
    }, 1000);
  });
  $("#contacto").click(function() {
    $("html, body").animate({
      scrollTop: $("#contact  ").offset().top
    }, 1000);
  });
  $("#footerBtn").click(function() {
    $("html, body").animate({
      scrollTop: $("#home  ").offset().top
    }, 1000);
  });
});
